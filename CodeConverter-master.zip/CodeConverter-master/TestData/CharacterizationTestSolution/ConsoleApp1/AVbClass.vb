﻿Imports System.Runtime.InteropServices
Imports System

Module Module1
    Public Sub Main()
    End Sub
End Module
