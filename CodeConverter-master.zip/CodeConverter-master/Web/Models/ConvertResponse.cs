﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeConverterWebApp.Models
{
    public class ConvertResponse
    {
        public bool conversionOk { get; set; }
        public string convertedCode { get; set; }
        public string errorMessage { get; set; }
    }
}
