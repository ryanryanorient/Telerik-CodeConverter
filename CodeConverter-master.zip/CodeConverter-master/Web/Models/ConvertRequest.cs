﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeConverterWebApp.Models
{
    public class ConvertRequest
    {
        public string code { get; set; }
        public string requestedConversion { get; set; }
    }

}
